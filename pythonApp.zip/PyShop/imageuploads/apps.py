from django.apps import AppConfig


class ImageuploadsConfig(AppConfig):
    name = 'imageuploads'
