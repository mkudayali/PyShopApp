from django.apps import AppConfig


class EmployeeportalConfig(AppConfig):
    name = 'employeePortal'
